from pathlib import Path
import hashlib


class FileManager:
    """the utility class for file operations."""
    
    @staticmethod
    def generate_note_id(title: str, timestamp: float) -> str:
        """generates a unique note filename."""
        safe_title = "".join([c if c.isalnum() else '_' for c in title])[:30]
        ts = int(timestamp)
        return f"{ts}_{safe_title}.md"
    
    @staticmethod
    def generate_panel_id(title: str, query: str) -> str:
        """generates a unique panel ID."""
        return hashlib.md5(f"{title}{query}".encode()).hexdigest()[:8]
    
    @staticmethod
    def sanitize_filename(filename: str) -> str:
        """sanitizes a string for use as filename."""
        return "".join([c if c.isalnum() or c in '._-' else '_' for c in filename])
    

    '''
    i want you to build a note making/taking tool as a terminal user interface or TUI. Use python and the python library "textual". I want the tool to have all the obvious features that a note making tool should have such as creation deletion, navigation and all that is expected from a complete note making tool. In addition to that, the tool should have the following features as well:
# Core Feature Set Reference

**Dynamic Dashboard Panels**
This feature transforms the startup view into a customizable grid of collapsible boxes where each panel represents a specific context defined by a query or target folder, allowing users to add, remove, or reorder panels directly via TUI commands without editing config files. When a panel is focused, typing immediately creates a new note with implicit metadata based on the panel's context, while existing notes within that view are listed below for quick access, ensuring organization happens at the moment of creation rather than as a cleanup step. Panels can be collapsed to hide content and save screen space, expanded for full visibility, and navigated via keyboard shortcuts, maintaining a clean, box-drawn interface that adapts to terminal size while enabling power-user customization without leaving the application.

**One-Key Priority Weight**
This feature enables rapid triage by allowing users to cycle a note's importance level (e.g., none to `!!!`) using a single keypress like `!`, storing the value as a simple integer in the note's frontmatter. The TUI reflects this state visually through colored prefixes or bold text in the note list, enabling instant filtering via commands to surface high-priority items without manual tagging. It prioritizes keyboard flow and zero-friction categorization, ensuring critical notes stand out immediately while remaining lightweight to implement.

**Neglected Label**
By tracking a `last_viewed` timestamp separate from the modification date, this feature automatically identifies notes that haven't been opened within a configurable threshold and marks them as neglected. These notes appear dimmed in the main list or can be isolated via a filter, prompting the user to review, renew, or archive stale content without manual organization. This passive maintenance tool encourages rediscovery of forgotten ideas and keeps the active workspace clean by highlighting information that has fallen out of the user's recent context.

**Temporal Proximity Threading**
This feature automatically surfaces related notes based on their creation timestamps, grouping content written within a specific window to reconstruct the user's original thought session. Displayed as a "Session Context" panel, it requires no manual linking and relies solely on existing `created` metadata to reveal episodic connections between seemingly unrelated notes. It aids memory recall by showing what else was captured during the same work burst, providing implicit context that traditional tag-based systems often miss.

---

### Integration Synergy
These features function as a cohesive system: the **Dashboard** serves as the central hub where **Priority** weights sort panel contents and **Neglected** notes appear dimmed for review. When a user opens a note from any panel, the **Temporal Threading** view appears below, offering context without clutter. This creates a workflow where capture is frictionless (Dashboard), triage is instant (Priority), maintenance is passive (Neglected), and discovery is automatic (Temporal).


The color theme of the tool should be black, grey, lavender/purple hues, and white minimally only where needed. I want the tool error free and ready to use.
    '''