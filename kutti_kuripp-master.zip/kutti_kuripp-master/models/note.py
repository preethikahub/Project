"""Note data model and management."""

from __future__ import annotations

import json
import hashlib
from datetime import datetime
from pathlib import Path
from typing import Any, Optional, Tuple

import yaml

from config import NOTES_DIR, DASHBOARD_CONFIG_PATH, DEFAULT_DASHBOARD_PANELS, APP_DIR
# Import DatabaseManager after config to avoid circular issues
from .database import DatabaseManager


class Note:
    """Represents a single note with metadata."""
    
    def __init__(self, path: Path, data: dict = None):
        self.path = path
        self.data = data or {}
        
    @property
    def title(self) -> str:
        return self.data.get('title', self.path.stem)
    
    @property
    def created(self) -> float:
        return self.data.get('created', 0)
    
    @property
    def modified(self) -> float:
        return self.data.get('modified', 0)
    
    @property
    def last_viewed(self) -> float:
        return self.data.get('last_viewed', 0)
    
    @property
    def priority(self) -> int:
        return self.data.get('priority', 0)
    
    @property
    def tags(self) -> list:
        return self.data.get('tags', [])
    
    def to_dict(self) -> dict:
        return {
            'path': str(self.path),
            'title': self.title,
            'created': self.created,
            'modified': self.modified,
            'last_viewed': self.last_viewed,
            'priority': self.priority,
            'tags': self.tags
        }
    
    @staticmethod
    def generate_filename(title: str) -> str:
        """Generate a unique note filename."""
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe_title = "".join([c if c.isalnum() else '_' for c in title])[:30]
        return f"{ts}_{safe_title}.md"
    
    @staticmethod
    def generate_panel_id(title: str, query: str) -> str:
        """Generate a unique panel ID."""
        return hashlib.md5(f"{title}{query}".encode()).hexdigest()[:8]


class NoteManager:
    """Manages note creation, retrieval, and persistence."""
    
    def __init__(self):
        # FIX: Ensure directories exist BEFORE creating DatabaseManager
        self._ensure_directories()
        self.db = DatabaseManager()
        self._load_dashboard_config()
        
    def _ensure_directories(self):
        """Create necessary directories if they don't exist."""
        APP_DIR.mkdir(parents=True, exist_ok=True)
        NOTES_DIR.mkdir(parents=True, exist_ok=True)
        
    def _load_dashboard_config(self):
        """Load dashboard panel configuration."""
        if DASHBOARD_CONFIG_PATH.exists():
            with open(DASHBOARD_CONFIG_PATH, 'r') as f:
                self.dashboard_panels = json.load(f)
        else:
            self.dashboard_panels = DEFAULT_DASHBOARD_PANELS.copy()
            self._save_dashboard_config()
    
    def _save_dashboard_config(self):
        """Save dashboard panel configuration."""
        with open(DASHBOARD_CONFIG_PATH, 'w') as f:
            json.dump(self.dashboard_panels, f, indent=2)
    
    def read_metadata(self, path: Path) -> dict:
        """Read YAML frontmatter from a note file."""
        if not path.exists():
            return {}
        try:
            with open(path, 'r', encoding='utf-8') as f:
                content = f.read()
            if content.startswith("---"):
                parts = content.split("---", 2)
                if len(parts) >= 3:
                    meta = yaml.safe_load(parts[1]) or {}
                    return meta
        except Exception:
            pass
        return {}
    
    def save_note(self, path: Path, content: str, meta: dict):
        """Save note content and metadata to file."""
        frontmatter = "---\n" + yaml.dump(meta, sort_keys=False) + "---\n"
        full_content = frontmatter + content
        
        with open(path, 'w', encoding='utf-8') as f:
            f.write(full_content)
        
        meta['modified'] = datetime.now().timestamp()
        meta['tags'] = meta.get('tags', [])  # Ensure tags is always a list
        self.db.index_note(path, meta)
    
    def create_note(self, title: str, context_meta: dict = None) -> Path:
        """Create a new note file."""
        filename = Note.generate_filename(title)
        path = NOTES_DIR / filename
        
        meta = {
            "title": title,
            "created": datetime.now().timestamp(),
            "modified": datetime.now().timestamp(),
            "last_viewed": datetime.now().timestamp(),
            "priority": 0,
            "tags": []
        }
        if context_meta:
            meta.update(context_meta)
            
        self.save_note(path, "", meta)
        return path
    
    def delete_note(self, path: Path):
        """Delete a note file and remove from database."""
        if path.exists():
            path.unlink()
        self.db.delete_note(path)
    
    def update_last_viewed(self, path: Path):
        """Update the last viewed timestamp for a note."""
        ts = datetime.now().timestamp()
        self.db.update_last_viewed(path, ts)
    
    def get_notes(self, query: str = None) -> list[dict]:
        """Get notes from database, optionally filtered by query."""
        return self.db.get_notes(query)
    
    def get_temporal_thread(self, created_ts: float) -> list[dict]:
        """Get notes created within temporal window of given timestamp."""
        return self.db.get_temporal_thread(created_ts)
    
    def add_dashboard_panel(self, title: str, query: str):
        """Add a new panel to the dashboard configuration."""
        self.dashboard_panels.append({
            "id": Note.generate_panel_id(title, query),
            "title": title,
            "query": query
        })
        self._save_dashboard_config()
    
    def remove_dashboard_panel(self, panel_id: str):
        """Remove a panel from the dashboard configuration."""
        self.dashboard_panels = [
            p for p in self.dashboard_panels if p['id'] != panel_id
        ]
        self._save_dashboard_config()
    
    def get_note_content(self, path: Path) -> Tuple[str, dict]:
        """Get note body content and metadata separately."""
        if not path.exists():
            return "", {}
        try:
            with open(path, 'r', encoding='utf-8') as f:
                content = f.read()
            if content.startswith("---"):
                parts = content.split("---", 2)
                if len(parts) >= 3:
                    meta = yaml.safe_load(parts[1]) or {}
                    return parts[2], meta
            return content, {}
        except Exception:
            return "", {}
    
    def search_notes(self, search_term: str) -> list[dict]:
        """Search notes by title or content."""
        all_notes = self.get_notes()
        results = []
        search_lower = search_term.lower()
        
        for note in all_notes:
            if search_lower in note.get('title', '').lower():
                results.append(note)
                continue
            
            # Search in file content
            path = Path(note['path'])
            if path.exists():
                body, _ = self.get_note_content(path)
                if search_lower in body.lower():
                    results.append(note)
        
        return results