"""Database management for note indexing."""

import sqlite3
import json  # <-- ADD THIS IMPORT
from datetime import timedelta, datetime
from pathlib import Path

from config import DB_PATH, NOTES_DIR, APP_DIR, NEGLECT_THRESHOLD_DAYS, TEMPORAL_WINDOW_HOURS


class DatabaseManager:
    """Manages SQLite database for note indexing and queries."""
    
    def __init__(self):
        # Ensure APP_DIR exists BEFORE trying to connect to database
        APP_DIR.mkdir(parents=True, exist_ok=True)
        
        self.conn = sqlite3.connect(str(DB_PATH), check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self._init_schema()
        self.reindex_all()
        
    def _init_schema(self):
        """Initialize database schema."""
        c = self.conn.cursor()
        c.execute("""
            CREATE TABLE IF NOT EXISTS notes (
                path TEXT PRIMARY KEY,
                title TEXT,
                created REAL,
                modified REAL,
                last_viewed REAL,
                priority INTEGER DEFAULT 0,
                tags TEXT  -- Store as JSON string
            )
        """)
        self.conn.commit()
    
    def reindex_all(self):
        """Reindex all note files in the notes directory."""
        NOTES_DIR.mkdir(parents=True, exist_ok=True)
        for file in NOTES_DIR.glob("*.md"):
            self.index_note(file)
        self.conn.commit()
    
    def index_note(self, path: Path, meta: dict = None):
        """Index a single note file."""
        if meta is None:
            meta = self._read_metadata_fallback(path)
        
        # FIX: Serialize tags list to JSON string for SQLite
        tags_json = json.dumps(meta.get('tags', []))
        
        c = self.conn.cursor()
        c.execute("""
            INSERT OR REPLACE INTO notes 
            (path, title, created, modified, last_viewed, priority, tags)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            str(path),
            meta.get('title', path.stem),
            meta.get('created', 0),
            meta.get('modified', 0),
            meta.get('last_viewed', 0),
            meta.get('priority', 0),
            tags_json  # <-- Store as JSON string
        ))
        self.conn.commit()
    
    def _read_metadata_fallback(self, path: Path) -> dict:
        """Fallback metadata reader to avoid circular imports."""
        import yaml
        if not path.exists():
            return {}
        try:
            with open(path, 'r', encoding='utf-8') as f:
                content = f.read()
            if content.startswith("---"):
                parts = content.split("---", 2)
                if len(parts) >= 3:
                    meta = yaml.safe_load(parts[1]) or {}
                    return meta
        except Exception:
            pass
        return {}
    
    def delete_note(self, path: Path):
        """Delete a note from the database."""
        c = self.conn.cursor()
        c.execute("DELETE FROM notes WHERE path=?", (str(path),))
        self.conn.commit()
    
    def update_last_viewed(self, path: Path, timestamp: float):
        """Update last viewed timestamp."""
        c = self.conn.cursor()
        c.execute("UPDATE notes SET last_viewed=? WHERE path=?", 
                  (timestamp, str(path)))
        self.conn.commit()
    
    def get_notes(self, query: str = None) -> list[dict]:
        """Get notes with optional query filtering."""
        c = self.conn.cursor()
        sql = "SELECT * FROM notes ORDER BY modified DESC"
        params = []
        
        if query:
            conditions = []
            parts = query.split()
            for p in parts:
                if p.startswith("priority:"):
                    val = p.split(":")[1]
                    if val.isdigit():
                        conditions.append("priority = ?")
                        params.append(int(val))
                elif p.startswith("recent:"):
                    days = int(p.split(":")[1])
                    cutoff = (datetime.now() - timedelta(days=days)).timestamp()
                    conditions.append("modified > ?")
                    params.append(cutoff)
            
            if conditions:
                sql = f"SELECT * FROM notes WHERE {' AND '.join(conditions)} ORDER BY modified DESC"
        
        c.execute(sql, params)
        
        # FIX: Parse tags JSON string back to list
        results = []
        for row in c.fetchall():
            row_dict = dict(row)
            if row_dict.get('tags'):
                try:
                    row_dict['tags'] = json.loads(row_dict['tags'])
                except (json.JSONDecodeError, TypeError):
                    row_dict['tags'] = []
            else:
                row_dict['tags'] = []
            results.append(row_dict)
        return results
    
    def get_temporal_thread(self, created_ts: float) -> list[dict]:
        """Get notes created within temporal window."""
        c = self.conn.cursor()
        start = created_ts - (TEMPORAL_WINDOW_HOURS * 3600)
        end = created_ts + (TEMPORAL_WINDOW_HOURS * 3600)
        c.execute("""
            SELECT * FROM notes 
            WHERE created BETWEEN ? AND ? 
            AND created != ?
            ORDER BY created ASC
        """, (start, end, created_ts))
        
        # FIX: Parse tags JSON string back to list
        results = []
        for row in c.fetchall():
            row_dict = dict(row)
            if row_dict.get('tags'):
                try:
                    row_dict['tags'] = json.loads(row_dict['tags'])
                except (json.JSONDecodeError, TypeError):
                    row_dict['tags'] = []
            else:
                row_dict['tags'] = []
            results.append(row_dict)
        return results
    
    def get_all_notes(self) -> list[dict]:
        """Get all notes without filtering."""
        c = self.conn.cursor()
        c.execute("SELECT * FROM notes ORDER BY modified DESC")
        
        # FIX: Parse tags JSON string back to list
        results = []
        for row in c.fetchall():
            row_dict = dict(row)
            if row_dict.get('tags'):
                try:
                    row_dict['tags'] = json.loads(row_dict['tags'])
                except (json.JSONDecodeError, TypeError):
                    row_dict['tags'] = []
            else:
                row_dict['tags'] = []
            results.append(row_dict)
        return results