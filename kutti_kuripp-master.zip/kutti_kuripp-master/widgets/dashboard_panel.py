from textual.widgets import Static, ListView
from textual.containers import Vertical

from .note_list import NoteListItem


class DashboardPanel(Static):
    """a collapsible panel displaying notes matching a query."""
    
    def __init__(self, panel_config: dict, note_manager, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.config = panel_config
        self.nm = note_manager
        self.collapsed = False
    
    def compose(self):
        with Vertical(classes="panel-container") as v:
            v.can_focus = True
            yield Static(f"[{self.config['title']}]", classes="panel-header")
            yield ListView(id=f"list-{self.config['id']}")
    
    def on_mount(self):
        self.refresh_notes()
    
    def refresh_notes(self):
        """refreshes the note list in this panel."""
        lv = self.query_one(f"#list-{self.config['id']}", ListView)
        if lv:
            lv.clear()
            notes = self.nm.get_notes(self.config['query'])
            for note in notes[:10]:  # Limit for performance
                lv.append(NoteListItem(note))
    
    def toggle_collapse(self):
        """toggles panel's collapsed state."""
        self.collapsed = not self.collapsed
        lv = self.query_one(f"#list-{self.config['id']}", ListView)
        if lv:
            lv.display = not self.collapsed