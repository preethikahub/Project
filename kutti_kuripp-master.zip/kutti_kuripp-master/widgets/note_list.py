from datetime import datetime
from textual.widgets import Static, ListItem

from config import Colors, NEGLECT_THRESHOLD_DAYS

class NoteListItem(ListItem):
    '''a list item representing a note with its priority and neglect indicators'''

    def __init__(self, note_data: dict, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.note_data = note_data

    def compose(self):
        priority = self.note_data.get("priority", 0)
        last_viewed = self.note_data("last_viewed", 0)
        title = self.note_data("title", "Untitled")

        is_neglected = (datetime.now().timestamp() - last_viewed) > (NEGLECT_THRESHOLD_DAYS * 86400)

        p_icon = ""
        p_color = ""
        if priority == 1:
            p_icon = "!"
            p_color = Colors.PRIORITY_1
        elif priority == 2:
            p_icon = "!!"
            p_color = Colors.PRIORITY_2
        elif priority == 3:
            p_icon = "!!!"
            p_color = Colors.PRIORITY_3

        if is_neglected:
            style = f"color: {Colors.NEGLECTED}; text-style: italic"
        else:
            style = f"color: {Colors.TEXT}"
        
        content = f"{p_icon} {title}" if p_icon else title
        yield Static(content, classes="note-item-content", _inline_styles = style)
        