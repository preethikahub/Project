from pathlib import Path
from textual.widgets import Static, ListView, ListItem

from .note_list import NoteListItem
from config import TEMPORAL_WINDOW_HOURS


class TemporalThreadWidget(Static):
    """displays notes created within temporal proximity of selected note."""
    
    def __init__(self, note_manager, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.nm = note_manager
        self.current_note_path = None
    
    def compose(self):
        yield Static("Session Context (Temporal)", classes="section-title")
        yield ListView(id="temporal-list")
    
    def update_context(self, note_path: str):
        """updates the temporal thread based on selected note."""
        self.current_note_path = note_path
        meta = self.nm.read_metadata(Path(note_path))
        created = meta.get('created', 0)
        
        lv = self.query_one("#temporal-list", ListView)
        lv.clear()
        
        related = self.nm.get_temporal_thread(created)
        if not related:
            lv.append(ListItem(Static("No nearby notes in this session.")))
        else:
            for note in related:
                lv.append(NoteListItem(note))