# kutti_kuripp
A TUI-based note-making tool with few modest twists. 
Work in progress