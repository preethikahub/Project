from app import KuttiKuripp


def main():
    """Run the notes application."""
    app = KuttiKuripp()
    app.run()


if __name__ == "__main__":
    main()