from pathlib import Path
from textual.screen import ModalScreen
from textual.widgets import Button, TextArea, Static
from textual.containers import Container, Horizontal
from textual.binding import Binding

from config import Colors
from .confirm import ConfirmScreen

class EditorScreen(ModalScreen):
    """the modal screen for editing note content."""
    
    BINDINGS = [
        Binding("ctrl+s", "save", "Save"),
        Binding("escape", "close", "Close"),
        Binding("!", "cycle_priority", "Priority"),
        Binding("ctrl+d", "delete", "Delete", show=False),
    ]
    
    def __init__(self, note_path: str, note_manager, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.note_path = note_path
        self.nm = note_manager
        self.meta = {}
        self.body = ""
    
    def compose(self):
        with Container(classes="editor-modal"):
            yield Static(
                f"Editing: {Path(self.note_path).name}", 
                classes="modal-header"
            )
            yield TextArea(id="editor", language="markdown")
            with Horizontal(classes="modal-footer"):
                yield Button("Save & Close", variant="primary", id="btn-save")
                yield Button("Delete Note", variant="error", id="btn-delete")
    
    def on_mount(self):
        """load note content on mount."""
        self.body, self.meta = self.nm.get_note_content(Path(self.note_path))
        
        ta = self.query_one("#editor", TextArea)
        ta.load_text(self.body)
        self.nm.update_last_viewed(Path(self.note_path))
    
    def action_save(self):
        """saves note and closes editor."""
        self._do_save()
        self.app.pop_screen()
    
    def action_close(self):
        """closes editor without saving."""
        self.app.pop_screen()
    
    def action_cycle_priority(self):
        """cycle priority level (0-3)."""
        current = self.meta.get('priority', 0)
        self.meta['priority'] = (current + 1) % 4
        self._do_save()
        priority_labels = {0: "None", 1: "!", 2: "!!", 3: "!!!"}
        self.app.notify(f"Priority: {priority_labels[self.meta['priority']]}")
    
    def action_delete(self):
        """deletes note from editor."""
        def confirm(delete):
            if delete:
                self.nm.delete_note(Path(self.note_path))
                self.app.notify("Note Deleted")
                self.app.pop_screen()
        
        self.app.push_screen(
            ConfirmScreen("Delete this note?"),
            confirm
        )
    
    def _do_save(self):
        """Save current editor content to file."""
        ta = self.query_one("#editor", TextArea)
        content = ta.text
        self.meta['title'] = self.meta.get('title', Path(self.note_path).stem)
        self.nm.save_note(Path(self.note_path), content, self.meta)
        self.app.notify("Note Saved")
    
    def on_button_pressed(self, event: Button.Pressed):
        """Handle button press events."""
        if event.button.id == "btn-save":
            self.action_save()
        elif event.button.id == "btn-delete":
            self.action_delete()