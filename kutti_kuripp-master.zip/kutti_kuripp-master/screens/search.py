from textual.screen import ModalScreen
from textual.widgets import Button, Input, Static, ListView
from textual.containers import Container, Horizontal, Vertical

from widgets import NoteListItem


class SearchScreen(ModalScreen):
    """the modal screen for searching notes."""
    
    def compose(self):
        with Container(classes="editor-modal"):
            yield Static("Search Notes", classes="modal-header")
            yield Input(placeholder="Search term...", id="inp-search")
            yield ListView(id="search-results")
            with Horizontal(classes="modal-footer"):
                yield Button("Open Selected", variant="primary", id="btn-open")
                yield Button("Close", variant="default", id="btn-close")
    
    def on_input_changed(self, event: Input.Changed):
        """handles search input changes."""
        if event.input.id == "inp-search":
            self._perform_search(event.value)
    
    def _perform_search(self, query: str):
        """performs search and updates results."""
        if not query:
            return
        
        from models import NoteManager
        nm = NoteManager()
        results = nm.search_notes(query)
        
        lv = self.query_one("#search-results", ListView)
        lv.clear()
        
        for note in results[:20]:  # Limit results
            lv.append(NoteListItem(note))
    
    def on_button_pressed(self, event: Button.Pressed):
        """handles button press events."""
        if event.button.id == "btn-open":
            lv = self.query_one("#search-results", ListView)
            if lv.highlighted_child:
                note_data = lv.highlighted_child.note_data
                self.dismiss(note_data.get('path'))
            else:
                self.dismiss(None)
        elif event.button.id == "btn-close":
            self.dismiss(None)
    
    def on_key(self, event):
        """handles key events."""
        if event.key == "enter":
            lv = self.query_one("#search-results", ListView)
            if lv.highlighted_child:
                note_data = lv.highlighted_child.note_data
                self.dismiss(note_data.get('path'))