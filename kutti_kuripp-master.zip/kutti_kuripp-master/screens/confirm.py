from textual.screen import ModalScreen
from textual.widgets import Button, Static
from textual.containers import Container, Horizontal


class ConfirmScreen(ModalScreen):
    """the modal screen for confirming destructive actions."""
    
    def __init__(self, message: str, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.message = message
    
    def compose(self):
        with Container(classes="editor-modal"):
            yield Static(self.message, classes="modal-header")
            with Horizontal(classes="modal-footer"):
                yield Button("Yes", variant="error", id="btn-yes")
                yield Button("No", variant="default", id="btn-no")
    
    def on_button_pressed(self, event: Button.Pressed):
        """handles button press events."""
        if event.button.id == "btn-yes":
            self.dismiss(True)
        else:
            self.dismiss(False)