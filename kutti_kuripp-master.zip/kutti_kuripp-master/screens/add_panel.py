from textual.screen import ModalScreen
from textual.widgets import Button, Input, Static
from textual.containers import Container, Horizontal

from config import Colors


class AddPanelScreen(ModalScreen):
    """the modal screen for adding a new dashboard panel."""
    
    def compose(self):
        with Container(classes="editor-modal"):
            yield Static("Add Dashboard Panel", classes="modal-header")
            yield Input(placeholder="Panel Title", id="inp-title")
            yield Input(placeholder="Query (e.g. priority:3)", id="inp-query")
            with Horizontal(classes="modal-footer"):
                yield Button("Add", variant="primary", id="btn-add")
                yield Button("Cancel", variant="default", id="btn-cancel")
    
    def on_button_pressed(self, event: Button.Pressed):
        """handles button press events."""
        if event.button.id == "btn-add":
            title = self.query_one("#inp-title", Input).value
            query = self.query_one("#inp-query", Input).value
            if title and query:
                self.dismiss((title, query))
            else:
                self.app.notify("Please fill in both fields", severity="error")
        elif event.button.id == "btn-cancel":
            self.dismiss(None)