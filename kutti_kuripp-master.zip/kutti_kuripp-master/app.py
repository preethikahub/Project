from pathlib import Path
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Grid, Container
from textual.widgets import Header, Footer
from textual.widgets import ListView

from config import Colors
from models import NoteManager
from widgets import DashboardPanel, TemporalThreadWidget, NoteListItem
from screens import EditorScreen, AddPanelScreen, ConfirmScreen, SearchScreen


class KuttiKuripp(App):
    """the main application class for kutti_kuripp."""
    
    CSS = f"""
    Screen {{
        background: {Colors.BG};
        color: {Colors.TEXT};
    }}
    
    Header {{
        background: {Colors.PANEL};
        color: {Colors.ACCENT};
        text-style: bold;
    }}
    
    Footer {{
        background: {Colors.PANEL};
        color: {Colors.ACCENT};
    }}
    
    .panel-container {{
        border: solid {Colors.BORDER};
        background: {Colors.PANEL};
        padding: 1;
        margin: 1;
        height: auto;
        max-height: 40%;
    }}
    
    .panel-header {{
        color: {Colors.ACCENT};
        text-style: bold;
        margin-bottom: 1;
    }}
    
    ListView {{
        background: transparent;
        height: auto;
    }}
    
    ListItem {{
        background: transparent;
        padding: 0 1;
    }}
    
    ListItem:focus {{
        background: {Colors.ACCENT_DIM};
        color: {Colors.TEXT_WHITE};
    }}
    
    .note-item-content {{
        width: 100%;
    }}
    
    #dashboard-grid {{
        grid-size: 2;
        grid-rows: 1fr 1fr;
        height: 60%;
    }}
    
    #main-area {{
        height: 40%;
        border: solid {Colors.BORDER};
        margin: 1;
        padding: 1;
    }}
    
    .section-title {{
        color: {Colors.ACCENT};
        text-style: bold;
        margin-bottom: 1;
    }}
    
    .editor-modal {{
        align: center middle;
        width: 90%;
        height: 90%;
        background: {Colors.PANEL};
        border: thick {Colors.ACCENT};
    }}
    
    TextArea {{
        width: 100%;
        height: 85%;
        background: #000000;
        color: {Colors.TEXT};
    }}
    
    .modal-header {{
        width: 100%;
        background: {Colors.ACCENT_DIM};
        color: {Colors.TEXT_WHITE};
        padding: 1;
        text-align: center;
    }}
    
    .modal-footer {{
        width: 100%;
        height: 15%;
        align: center middle;
    }}
    
    Button {{
        margin: 0 1;
    }}
    
    Input {{
        width: 100%;
        margin: 1 0;
    }}
    """
    
    BINDINGS = [
        Binding("n", "new_note", "New Note"),
        Binding("d", "delete_note", "Delete", show=False),
        Binding("a", "add_panel", "Add Panel"),
        Binding("r", "refresh", "Refresh"),
        Binding("c", "collapse_panel", "Collapse"),
        Binding("q", "quit", "Quit"),
        Binding("escape", "focus_dashboard", "Focus Dashboard"),
        Binding("/", "search", "Search"),
    ]
    
    def __init__(self):
        super().__init__()
        self.nm = NoteManager()
        self.selected_note_path = None
    
    def compose(self) -> ComposeResult:
        yield Header()
        with Grid(id="dashboard-grid"):
            # Panels injected dynamically
            pass
        with Container(id="main-area"):
            yield TemporalThreadWidget(self.nm, id="temporal-widget")
        yield Footer()
    
    def on_mount(self):
        """initializes dashboard on mount."""
        self.refresh_dashboard()
    
    def refresh_dashboard(self):
        """refreshes all dashboard panels."""
        grid = self.query_one("#dashboard-grid", Grid)
        grid.remove_children()
        for panel_config in self.nm.dashboard_panels:
            panel = DashboardPanel(
                panel_config, 
                self.nm, 
                id=f"panel-{panel_config['id']}"
            )
            grid.mount(panel)
    
    def action_new_note(self):
        """creates a new note."""
        path = self.nm.create_note("New Note")
        self.open_editor(str(path))
    
    def action_delete_note(self):
        """deletes currently selected note."""
        if self.selected_note_path:
            def confirm(delete):
                if delete:
                    self.nm.delete_note(Path(self.selected_note_path))
                    self.notify("Note Deleted")
                    self.refresh_dashboard()
                    self.selected_note_path = None
            
            self.push_screen(
                ConfirmScreen("Delete this note?"),
                confirm
            )
        else:
            self.notify("No note selected", severity="warning")
    
    def action_add_panel(self):
        """adds a new dashboard panel."""
        def handle_result(res):
            if res:
                title, query = res
                self.nm.add_dashboard_panel(title, query)
                self.refresh_dashboard()
                self.notify(f"Panel '{title}' Added")
        
        self.push_screen(AddPanelScreen(), handle_result)
    
    def action_refresh(self):
        """refreshes dashboard panels."""
        self.refresh_dashboard()
        self.notify("Dashboard Refreshed")
    
    def action_collapse_panel(self):
        """collapses/expands focused panel."""
        focused = self.focused
        if focused and isinstance(focused, DashboardPanel):
            focused.toggle_collapse()
            self.notify("Panel Collapsed" if focused.collapsed else "Panel Expanded")
    
    def action_focus_dashboard(self):
        """returns focus to dashboard from editor or other screens."""
        self.set_focus(self.query_one("#dashboard-grid"))
    
    def action_search(self):
        """opens search input."""
        def search_callback(note_path):
            if note_path:
                self.open_editor(note_path)
        
        self.push_screen(SearchScreen(), search_callback)
    
    def open_editor(self, path: str):
        """opens the editor screen for a note."""
        self.selected_note_path = path
        self.push_screen(EditorScreen(path, self.nm))
    
    def on_list_view_highlighted(self, event: ListView.Highlighted):
        """Handle note highlight in list."""
        if isinstance(event.item, NoteListItem):
            note_data = event.item.note_data
            path = note_data.get('path')
            if path:
                tw = self.query_one("#temporal-widget", TemporalThreadWidget)
                tw.update_context(path)
                self.selected_note_path = path
    
    def on_list_item_selected(self, event):
        """Handle note selection."""
        if isinstance(event.item, NoteListItem):
            path = event.item.note_data.get('path')
            if path:
                self.open_editor(path)