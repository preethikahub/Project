from pathlib import Path

APP_DIR = Path.home() / ".kutti_kuripp"
NOTES_DIR = APP_DIR / "notes"
DB_PATH = APP_DIR / "index.db"
DASHBOARD_CONFIG_PATH = APP_DIR / "dashboard.json"

# the theme Colors
class Colors:
    BG = "#050505"
    PANEL = "#121212"
    BORDER = "#4B4B68"
    ACCENT = "#B57EDC"
    ACCENT_DIM = "#6A4C93"
    TEXT = "#C0C0C0"
    TEXT_WHITE = "#FFFFFF"
    NEGLECTED = "#444444"
    PRIORITY_1 = "#B57EDC"
    PRIORITY_2 = "#9955DD"
    PRIORITY_3 = "#FF5555"

NEGLECT_THRESHOLD_DAYS = 30
TEMPORAL_WINDOW_HOURS = 24

DEFAULT_DASHBOARD_PANELS = [
    {"id": "p1", "title": "Inbox", "query": "priority:0"},
    {"id": "p2", "title": "High Priority", "query": "priority:3"},
    {"id": "p3", "title": "Recent", "query": "recent:7"}
]

KEYBINDINGS = {
    "new_note": "n",
    "delete_note": "d",
    "add_panel": "a",
    "refresh": "r",
    "collapse_panel": "c",
    "quit": "q",
    "focus_dashboard": "escape",
    "search": "/",
    "save": "ctrl+s",
    "close_editor": "escape",
    "cycle_priority": "!",
    "delete_from_editor": "ctrl+d",
    "navigate_up": "up",
    "navigate_down": "down",
    "open_note": "enter",
}